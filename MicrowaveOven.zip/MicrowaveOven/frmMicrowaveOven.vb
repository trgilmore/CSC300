﻿Public Class frmMicrowaveOven
    Public Property Green As Color

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        lblTime.Text = lblTime.Text & btn1.Text
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblTime.Text = "00:00"
        Panel1.BackColor = Color.LightGray
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        lblTime.Text = "RUNNING"
        Panel1.BackColor = Color.LightGreen
    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        lblTime.Text = lblTime.Text & btn2.Text
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        lblTime.Text = lblTime.Text & btn3.Text
    End Sub

    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        lblTime.Text = lblTime.Text & btn4.Text
    End Sub

    Private Sub btn5_Click(sender As Object, e As EventArgs) Handles btn5.Click
        lblTime.Text = lblTime.Text & btn5.Text
    End Sub

    Private Sub btn6_Click(sender As Object, e As EventArgs) Handles btn6.Click
        lblTime.Text = lblTime.Text & btn6.Text
    End Sub

    Private Sub btn7_Click(sender As Object, e As EventArgs) Handles btn7.Click
        lblTime.Text = lblTime.Text & btn7.Text
    End Sub

    Private Sub btn8_Click(sender As Object, e As EventArgs) Handles btn8.Click
        lblTime.Text = lblTime.Text & btn8.Text
    End Sub

    Private Sub btn9_Click(sender As Object, e As EventArgs) Handles btn9.Click
        lblTime.Text = lblTime.Text & btn9.Text
    End Sub

    Private Sub btn0_Click(sender As Object, e As EventArgs) Handles btn0.Click
        lblTime.Text = lblTime.Text & btn0.Text
    End Sub
End Class
